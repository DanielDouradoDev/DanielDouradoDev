# Portfólio — Daniel Dourado (V2)

Site estático com **HTML, CSS e JavaScript puro**, redesenhado com foco em velocidade, acessibilidade e responsividade. O tema inicial é **escuro** e existe um botão para alternar entre escuro e claro.

## Como abrir

1. Descompacte o ZIP.
2. Abra `index.html` no Chrome, Edge, Firefox ou Safari. Não é necessário instalar pacotes nem iniciar servidor.
3. Para publicar, envie o conteúdo da pasta a GitHub Pages, Netlify ou Vercel (site estático).

## Arquivos

- `index.html` — conteúdo e estrutura semântica do site.
- `style.css` — layout e estilos, incluindo breakpoints para desktop, tablet e celular.
- `script.js` — menu mobile, filtros dos projetos, modal de detalhes, tema claro/escuro, animações suaves, barra de progresso, botão de voltar ao topo e links de contato.
- `assets/daniel.jpg` — sua foto original (já aplicada no layout).
- `assets/favicon.svg` — ícone da aba do navegador.
- `previews/` — capturas de tela para conferência.

## Para colocar os seus contatos

Abra `script.js` e edite o objeto **`CONTACTS`** logo no início:

```js
const CONTACTS = {
  email: 'seuemail@dominio.com',
  linkedin: 'https://www.linkedin.com/in/seu-usuario/',
  github: 'https://github.com/seu-usuario'
};
```

Os links preenchidos aparecerão automaticamente na seção Contato. Se permanecerem vazios, o site exibe uma mensagem neutra, sem links fictícios.

## Trocar a foto

Substitua `assets/daniel.jpg` por outra foto com o mesmo nome. Para ajustar o enquadramento, altere a propriedade `object-position` da regra `.portrait-card img` em `style.css`.

## Alterar textos e projetos

- Textos e cards: edite o `index.html`.
- Detalhes que aparecem ao clicar em **Ver case**: edite o objeto `PROJECTS` em `script.js`.
- **Importante**: os dashboards e métricas visuais nos cards são ilustrações estáticas, não dados reais de produtos publicados.

## Interações implementadas

1. Menu responsivo com controle por teclado e `aria-expanded`.
2. Alternância escuro/claro persistente no navegador.
3. Filtros funcionais por categoria de projeto.
4. Caixas de diálogo acessíveis com detalhes de cada projeto.
5. Animações discretas de entrada; respeitam a preferência por reduzir movimento.
6. Destaque da seção ativa no menu desktop.
7. Barra de leitura e botão de retorno ao topo.
8. Atualização automática do ano no rodapé.

## Dados ainda faltando para uma versão pronta para recrutadores

Seu e-mail profissional, perfis do GitHub/LinkedIn, links reais de repositórios ou demos, currículo em PDF (se quiser disponibilizar) e tecnologias que você deseja destacar como já dominadas — distintas das que ainda está estudando.

### Observações

O portfólio apresenta os projetos como **conceitos, protótipos ou trabalhos acadêmicos**, sem sugerir métricas, clientes ou sistemas concluídos não comprovados.
