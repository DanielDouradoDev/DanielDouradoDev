/* PORTFÓLIO DANIEL — INTERAÇÕES
 * Para ativar seus contatos, preencha as URLs abaixo.
 * Nenhum endereço é inventado ou enviado a serviços externos.
 */
const CONTACTS = {
  email: '',                   // Exemplo: 'seuemail@dominio.com'
  linkedin: '',                // Exemplo: 'https://www.linkedin.com/in/usuario/'
  github: ''                   // Exemplo: 'https://github.com/usuario'
};

const PROJECTS = {
  reservei: {
    eyebrow: '01 / PROJETO ACADÊMICO', title: 'Reservei — Gestão de Reservas',
    lead: 'Um sistema concebido a partir da rotina real de um restaurante, considerando reserva de mesas, lista de espera, ocupação e operações de atendimento.',
    points: [
      'Mapeamento do cenário, entrevistas e identificação de regras de negócio.',
      'Modelagem conceitual e lógica de entidades como cliente, mesa, reserva, espera e ocupação.',
      'Estruturação de banco MySQL, relacionamentos e histórico de atribuições de mesas.',
      'Exercícios de lógica e estruturação de funcionalidades em C e Portugol.'
    ], tools: ['C', 'Portugol', 'MySQL', 'MER/DER'],
    note: 'Projeto acadêmico / em desenvolvimento. A interface exibida no card é ilustrativa.'
  },
  rota360: {
    eyebrow: '02 / CONCEITO DE SAAS', title: 'Rota360 Intelligence',
    lead: 'Proposta de produto para caminhoneiros e transportadoras, com foco em inteligência financeira e visibilidade sobre a rentabilidade das operações.',
    points: [
      'Mapeamento de dores relacionadas a custos operacionais, gestão e margens de transporte.',
      'Definição de proposta de valor e funcionalidades de um MVP de análise financeira.',
      'Estudo de arquitetura, entidades de dados e possíveis indicadores por rota e operação.',
      'Investigação de diferenciais competitivos que ainda precisam ser validados em campo.'
    ], tools: ['Produto', 'Dados', 'Arquitetura', 'SaaS'],
    note: 'Conceito de produto; não representa plataforma comercial já lançada.'
  },
  tea: {
    eyebrow: '03 / PROTÓTIPO UX/UI', title: 'Direitos TEA',
    lead: 'Experiência digital voltada ao acesso mais claro e acessível a informações sobre direitos de pessoas autistas e suas famílias.',
    points: [
      'Definição de uma paleta e tipografia voltadas à legibilidade e ao contraste.',
      'Estudo de arquitetura da informação e organização de telas e navegação.',
      'Criação de fluxos e protótipos de interface no Figma.',
      'Atenção à experiência de pessoas usuárias com diferentes necessidades.'
    ], tools: ['Figma', 'HTML', 'CSS', 'Acessibilidade'],
    note: 'Protótipo / estudo de UX. O card contém uma ilustração da interface.'
  },
  easypred: {
    eyebrow: '04 / CONCEITO DE PRODUTO', title: 'EasyPred',
    lead: 'Ideia de plataforma para ajudar a registrar e acompanhar tarefas de manutenção predial, com uma visão mais organizada de indicadores e relatórios.',
    points: [
      'Organização de informações de manutenção em um painel de consulta.',
      'Exploração de indicadores para acompanhamento de demandas e registros.',
      'Estudo de fluxos de cadastro, histórico e consulta de atividades.',
      'Priorização da clareza dos dados e da usabilidade do produto.'
    ], tools: ['UX', 'Dashboards', 'Produto', 'SaaS'],
    note: 'Conceito exploratório; métricas da ilustração são fictícias.'
  },
  hardtech: {
    eyebrow: '05 / CONCEITO DE IA', title: 'Hardtech IA',
    lead: 'Estudo de um assistente capaz de organizar etapas de diagnóstico e orientar dúvidas comuns de suporte e manutenção de hardware.',
    points: [
      'Desenho de um fluxo de triagem de dúvidas e identificação de problemas.',
      'Exploração de respostas estruturadas a partir dos sintomas informados.',
      'Possibilidades de automação de etapas repetitivas de atendimento.',
      'Reflexão sobre quando escalar a solicitação para uma pessoa especialista.'
    ], tools: ['IA', 'Automação', 'Suporte Técnico', 'Fluxos'],
    note: 'Estudo conceitual; não é um sistema de diagnóstico médico ou produto em produção.'
  }
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

// Tema claro/escuro: o padrão é escuro; preferência salva no navegador.
const root = document.documentElement;
const themeButton = $('#themeToggle');
let savedTheme = null;
try { savedTheme = localStorage.getItem('daniel-portfolio-theme'); } catch (_) {}
if (savedTheme === 'light' || savedTheme === 'dark') root.dataset.theme = savedTheme;
function updateThemeButton() {
  const light = root.dataset.theme === 'light';
  themeButton?.setAttribute('aria-label', light ? 'Ativar tema escuro' : 'Ativar tema claro');
  const metaTheme = $('meta[name="theme-color"]');
  if (metaTheme) metaTheme.content = light ? '#f6f8f4' : '#0a0c10';
}
updateThemeButton();
themeButton?.addEventListener('click', () => {
  root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
  try { localStorage.setItem('daniel-portfolio-theme', root.dataset.theme); } catch (_) {}
  updateThemeButton();
});

// Menu responsivo com teclado e gerenciamento de foco.
const menuButton = $('#menuToggle');
const mobileNav = $('#mobileNav');
function closeMenu(restoreFocus = false) {
  if (!menuButton || !mobileNav) return;
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Abrir menu');
  mobileNav.classList.remove('open');
  mobileNav.inert = true;
  if (restoreFocus) menuButton.focus();
}
function openMenu() {
  if (!menuButton || !mobileNav) return;
  mobileNav.inert = false;
  mobileNav.classList.add('open');
  menuButton.setAttribute('aria-expanded', 'true');
  menuButton.setAttribute('aria-label', 'Fechar menu');
  $('a', mobileNav)?.focus();
}
menuButton?.addEventListener('click', () => {
  menuButton.getAttribute('aria-expanded') === 'true' ? closeMenu(true) : openMenu();
});
$$('a', mobileNav).forEach(link => link.addEventListener('click', () => closeMenu()));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
document.addEventListener('click', event => {
  if (mobileNav?.classList.contains('open') && !event.target.closest('.site-header')) closeMenu();
});
window.addEventListener('resize', () => { if (window.innerWidth > 900) closeMenu(); });

// Filtros de projetos.
const filterButtons = $$('.filter-button');
const cards = $$('.project-card');
const filterResult = $('#filterResult');
filterButtons.forEach(button => button.addEventListener('click', () => {
  const filter = button.dataset.filter;
  filterButtons.forEach(other => {
    const active = other === button;
    other.classList.toggle('active', active);
    other.setAttribute('aria-pressed', String(active));
  });
  let count = 0;
  cards.forEach(card => {
    const match = filter === 'all' || (card.dataset.category || '').split(' ').includes(filter);
    card.hidden = !match;
    if (match) { count++; card.classList.add('is-visible'); }
  });
  if (filterResult) filterResult.textContent = count === 1 ? '1 projeto' : `${count} projetos`;
}));

// Modal de cases: conteúdo local, sem bibliotecas ou requisições externas.
const dialog = $('#projectDialog');
const dialogClose = $('#dialogClose');
function closeDialog() {
  if (!dialog?.open) return;
  dialog.close();
  document.body.classList.remove('dialog-open');
}
function openProject(id) {
  const project = PROJECTS[id];
  if (!project || !dialog) return;
  $('#dialogEyebrow').textContent = project.eyebrow;
  $('#dialogTitle').textContent = project.title;
  $('#dialogLead').textContent = project.lead;
  $('#dialogNote').textContent = project.note;
  const points = $('#dialogPoints');
  const tags = $('#dialogTools');
  points.replaceChildren();
  tags.replaceChildren();
  project.points.forEach(point => {
    const li = document.createElement('li');
    li.textContent = point;
    points.append(li);
  });
  project.tools.forEach(tool => {
    const tag = document.createElement('span');
    tag.textContent = tool;
    tags.append(tag);
  });
  if (typeof dialog.showModal === 'function') {
    dialog.showModal();
    document.body.classList.add('dialog-open');
    dialogClose?.focus();
  }
}
$$('[data-open-project]').forEach(button => button.addEventListener('click', () => openProject(button.dataset.openProject)));
dialogClose?.addEventListener('click', closeDialog);
$('#dialogDone')?.addEventListener('click', closeDialog);
dialog?.addEventListener('close', () => document.body.classList.remove('dialog-open'));
dialog?.addEventListener('click', event => { if (event.target === dialog) closeDialog(); });

// Links profissionais configuráveis; omitem-se URLs não cadastradas.
const contactLinks = $('#contactLinks');
if (contactLinks) {
  const channels = [
    { name: 'E-mail', value: CONTACTS.email.trim(), href: CONTACTS.email.trim() ? `mailto:${CONTACTS.email.trim()}` : '', secondary: false },
    { name: 'LinkedIn', value: CONTACTS.linkedin.trim(), href: CONTACTS.linkedin.trim(), secondary: true },
    { name: 'GitHub', value: CONTACTS.github.trim(), href: CONTACTS.github.trim(), secondary: true }
  ].filter(item => item.value && (item.name === 'E-mail' || /^https:\/\//i.test(item.href)));
  if (channels.length) {
    contactLinks.replaceChildren();
    channels.forEach(channel => {
      const a = document.createElement('a');
      a.className = `contact-link${channel.secondary ? ' secondary' : ''}`;
      a.href = channel.href;
      if (!channel.href.startsWith('mailto:')) { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
      a.textContent = channel.name + ' ↗';
      contactLinks.append(a);
    });
  }
}

// Revelação progressiva, navegação ativa, progresso e botão de topo.
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.documentElement.classList.add('js-ready');
  const revealObserver = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    }
  }, { rootMargin: '0px 0px -24px 0px', threshold: 0.08 });
  $$('.reveal').forEach(item => revealObserver.observe(item));
}
if ('IntersectionObserver' in window) {
  const links = $$('.nav-link');
  const sections = $$('main section[id]');
  const activeObserver = new IntersectionObserver(entries => {
    const visible = entries.filter(entry => entry.isIntersecting).sort((a,b) => b.intersectionRatio - a.intersectionRatio);
    if (!visible.length) return;
    links.forEach(link => link.classList.toggle('is-active', link.hash === '#' + visible[0].target.id));
  }, { rootMargin: '-20% 0px -60% 0px', threshold: 0 });
  sections.forEach(section => activeObserver.observe(section));
}
const progress = $('#readingProgress');
const backToTop = $('#backToTop');
let scrollScheduled = false;
function refreshScroll() {
  const maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  if (progress) progress.style.width = `${Math.min(100, window.scrollY / maxScroll * 100)}%`;
  backToTop?.classList.toggle('visible', window.scrollY > 650);
  scrollScheduled = false;
}
window.addEventListener('scroll', () => {
  if (!scrollScheduled) { window.requestAnimationFrame(refreshScroll); scrollScheduled = true; }
}, { passive: true });
refreshScroll();
backToTop?.addEventListener('click', () => window.scrollTo({top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth'}));
$('#currentYear').textContent = new Date().getFullYear();
